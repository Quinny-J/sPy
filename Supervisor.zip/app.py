from flask import Flask, jsonify, render_template
from datetime import datetime
from collections import deque
import threading
import time

app = Flask(__name__)

# Store the request counts
request_counts = deque(maxlen=60)  # Store counts for the last 60 seconds

# Initialize the request counts deque with zeros
for _ in range(60):
    request_counts.append(0)

@app.route('/')
def index():
    return render_template('r.html')

@app.route('/data')
def data():
    return jsonify(list(request_counts))

@app.before_request
def before_request():
    now = datetime.now()
    second = now.second
    request_counts[second] += 1

def reset_counts():
    while True:
        time.sleep(1)
        now = datetime.now()
        second = now.second
        request_counts[second] = 0

if __name__ == '__main__':
    # Start the reset counts thread
    thread = threading.Thread(target=reset_counts)
    thread.daemon = True
    thread.start()
    app.run(debug=True)
